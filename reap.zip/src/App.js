import React from 'react';
import Table from './components/table/table';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'admin-lte-css-only/css/adminlte.min.css';

import './App.css';
import Wrapper from './components/wrapper/wrapper';
import WrapperW from './components/wrapper/wrapperW';


function App() {
  return (
    <WrapperW>
     
    </WrapperW>
  );
}

export default App;