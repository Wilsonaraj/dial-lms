import './user-form.css';
function UserForm(){
    let pageTitle = "user form";
  let country= "";
  let state= "";
  let tier= "";
  let editMode= "";
  let imgStr = "http://edcadp.000webhostapp.com/php/upload/635ad02cc7121.jpeg";
    return(
<div className="p-3">

  
<form>
<div className="row"
id="client-data"

>
    
 
<div className="col-lg-6">
    <div className="form-group mb-3 mt-3">
      <label htmlFor="fname" className="form-label">Full Name:</label>
      <input 
      type="text" 
      className="form-control form-control-sm" 
      id="fname" 
      minLength="5"
      placeholder="Enter Full Name" 
      name="fname" 
      required
      
      />
      <p className="warn" >
        <span >Please enter atleast 5 letters!</span>
        <span >This field is mandatory!</span>
      </p>
    </div>
    

    <div className="mb-3 form-group">
      <label htmlFor="sname" className="form-label">Short Name:</label>
      <input type="text" 
      className="form-control form-control-sm" 
      minLength="3"
      id="sname" 
      placeholder="Enter Short Name" 
      name="sname" 
      
      required
      />
      <p className="warn" >
        <span >Please enter atleast 3 letters!</span>
        <span >This field is mandatory!</span>
      </p>
    </div>
    <div className="form-group mb-3">
        <label htmlFor="web" className="form-label">Client Website:</label>
        <input 
        type="text" 
        minLength="8"
        className="form-control form-control-sm" 
        id="web" 
        placeholder="Enter Short Name" 
        
        name="web" 
        
        required
        />
        <p className="warn" >
          <span >Please enter valid Website!</span>
          <span >This field is mandatory!</span>
        </p>
      </div>
    
      <div className="mb-3">
        <label htmlFor="adr" className="form-label">Client Address:</label>
        <textarea 
        type="text" rows="4" cols="50" 
        className="form-control form-control-sm" id="adr" 
        placeholder="Enter Address" 
        name="adr"
      
        minLength="10"
        
        required
        ></textarea>
        <p className="warn" >
          <span >Please enter valid Address</span>
          <span >This field is mandatory!</span>
        </p>
      </div>

      <div className="mb-3">
        <label htmlFor="cnt" className="form-label">Country:</label>
        
        <select 
        
        className="form-control form-control-sm form-select" 
        id="cnt" 
      
        name="cnt"
        
        required
        >
        
        
        <option >{country.name}</option>
        </select>
        <p className="warn" >
              
          <span>This field is mandatory!</span>
        </p>
      </div>
        <div className="mb-3">
            <label htmlFor="stt" className="form-label">State:</label>
            <select 
            type="text" 
            className="form-control form-control-sm form-select" 
            id="stt"  
         
            name="stt"
            
            required
            >

            <option  >{state.name}</option>
            </select>
            <p className="warn" >
              
              <span >This field is mandatory!</span>
            </p>
          </div>

            <div className="mb-3">
                <label htmlFor="cty" className="form-label">City:</label>
                <input 
                type="text" 
                className="form-control form-control-sm" 
                id="cty" 
               
                placeholder="Enter City" 
                name="cty"
                
            required
                />
                <p className="warn" >
              
                  <span>This field is mandatory!</span>
                </p>
              </div>
          
      </div>
    

<div className="col-lg-6">
    <div className="mb-3 mt-3">
      <label htmlFor="imgPath" className="form-label">Upload Image: </label>
      
  
      <img src={imgStr} className="img-thumbnail form-img"  alt=""/>
        
        <input 
        className="form-control form-control-sm" 
        
        placeholder="Chooser Image File" 
        type="file" 
        id="imgPath"
     
        name="imgPath"
       
        />
        <p className="warn" >
              
        
        </p>
    
    </div>

    <div className="mb-3">
        <label htmlFor="mob" className="form-label">Mobile Number:</label>
        <input 
        type="text" 
        className="form-control form-control-sm" 
        id="mob" 
        placeholder="Enter Mobile Number"
        name="mob"
      
        
        pattern="^(?!0+$)(?:\(?\+\d{1,3}\)?[- ]?|0)?\d{10}$"
        required
        />
        <p className="warn" >
              
          <span >This field is mandatory!</span>
        </p>
      </div>

      <div className="mb-3">
        <label htmlFor="offp" className="form-label">Office Phone:</label>
        <input 
        type="text" 
        className="form-control form-control-sm" 
        id="offp" 
    
        placeholder="Enter Office Phone" 
        name="offp"
        pattern="^(?!0+$)(?:\(?\+\d{1,3}\)?[- ]?|0)?\d{10}$"
        
        required
       />
        <p className="warn" >
              
          <span>This field is mandatory!</span>
        </p>
      </div>
      <div className="mb-3">
        <label htmlFor="ter" className="form-label">Tier:</label>
        <select 
        type="number" 
        className="form-control form-control-sm form-select" 
        id="ter" 
      
        placeholder="Enter Tier" 
        name="ter"
        
        required
        >
      <option>{tier.name}</option>
        </select>
        <p className="warn" >
              
          <span>This field is mandatory!</span>
        </p>
      </div>

    <p className="warn" >Form is invalid!</p>
      <button type="submit" className="btn btn-primary brnd">{ editMode ? 'Update' : 'Submit' }</button>
      
</div>
    
  
</div>

</form>
</div>
    )
}
export default UserForm;