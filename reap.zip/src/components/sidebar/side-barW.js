import React,{useState} from 'react';
import './sidebar.css';
/* import logo from "../../assets/img/AdminLTELogo.png"; */
import logo from '../../assets/img/credit/cirrus.png'
import userImg from "../../assets/img/user2-160x160.jpg";
import SideBarLi from './sidebar-li'
import TableW from "../table/table-w";
import { PropaneSharp } from '@mui/icons-material';
import FormicW from '../formic/formicW';
import TableWClient from '../table/table-w-c';
import AddRole from '../roles/add-role';
import SignupForm from '../forms/form';



function SidebarW(props){
  const [openStatus ,setOpenStatus]= useState(false);
  /* const AddTab = (comp,props)=>{
    console.log(comp)
    props.AddTab(comp) 
  } */
    return(
<aside className="main-sidebar sidebar-dark-primary elevation-4">

    <a className="brand-link">
      <img src={logo} alt="AdminLTE Logo" className="brand-image img-circle elevation-3" />
      <span className="brand-text font-weight-light">EDC</span>
    </a>


    <div className="sidebar">

      {/* <div className="user-panel mt-3 pb-3 mb-3 d-flex">
        <div className="image">
          <img src={userImg} className="img-circle elevation-2" alt="User Image"/>
        </div>
        <div className="info">
          <a href="#" className="d-block">Alexander Pierce</a>
        </div>
      </div> */}


     {/*  <div className="form-inline">
        <div className="input-group" data-widget="sidebar-search">
          <input className="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search"/>
          <div className="input-group-append">
            <button className="btn btn-sidebar">
              <i className="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>
 */}
      <nav className="mt-2">
        <ul className="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
     
          {/* <li className="nav-item">
            <a href="#" className="nav-link">
              <i className="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <i className="right fas fa-angle-left"></i>
              </p>
            </a> */}
           <SideBarLi text="User Management" class="fas fa-users" active="active" setOpenStatus={(stat)=>setOpenStatus(stat)}>
            <ul className="nav nav-treeview">
          
              <SideBarLi text="Users" class="far fa-circle" 
              comp={{id:0,name:"Users",comp:<TableW/>}} AddTab={props.AddTab}/>
              <SideBarLi text="Clients" class="far fa-circle" 
              comp={{id:1,name:"Clients",comp:<TableWClient />}} AddTab={props.AddTab}/>
              <SideBarLi text="Add Client" class="far fa-circle" 
              comp={{id:2,name:"Add Client",comp:<FormicW />}} AddTab={props.AddTab} />
              <SideBarLi text="Add Role" class="far fa-circle" 
              comp={{id:3,name:"Add Role",comp:<AddRole />}} AddTab={props.AddTab} />
              <SideBarLi text="Signup Form" class="far fa-circle" 
              comp={{id:4,name:"Signup Form",comp:<SignupForm />}} AddTab={props.AddTab} />
              
            </ul>
            </SideBarLi>
     
 
          
            <SideBarLi text="Layout Options" class="fas fa-copy" >

            
            <ul className="nav nav-treeview">
              <li className="nav-item">
                <a href="../layout/top-nav.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Top Navigation</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../layout/top-nav-sidebar.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Top Navigation + Sidebar</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../layout/boxed.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Boxed</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../layout/fixed-sidebar.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Fixed Sidebar</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../layout/fixed-sidebar-custom.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Fixed Sidebar <small>+ Custom Area</small></p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../layout/fixed-topnav.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Fixed Navbar</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../layout/fixed-footer.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Fixed Footer</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../layout/collapsed-sidebar.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Collapsed Sidebar</p>
                </a>
              </li>
            </ul>
            </SideBarLi>

            <SideBarLi text="Charts" class=" fas fa-chart-pie" >
            <ul className="nav nav-treeview">
              <li className="nav-item">
                <a href="../charts/chartjs.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>ChartJS</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../charts/flot.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Flot</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../charts/inline.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Inline</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../charts/uplot.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>uPlot</p>
                </a>
              </li>
            </ul>
            </SideBarLi>
          {/* <li className="nav-item menu-open">
            <a href="#" className="nav-link active">
              <i className="nav-icon fas fa-tree"></i>
              <p>
                UI Elements
                <i className="fas fa-angle-left right"></i>
              </p>
            </a> */}
            <SideBarLi text="UI Elements" class="fas fa-tree" >
            <ul className="nav nav-treeview">
              
              <SideBarLi text="General" class="far fa-circle"/>
              <SideBarLi text="Icons" class="far fa-circle"/>
              <SideBarLi text="Buttons" class="far fa-circle"/>
              <SideBarLi text="Sliders" class="far fa-circle"/>
              <SideBarLi text="Modals & Alerts" class="far fa-circle"/>
              <SideBarLi text="Navbar & Tabs" class="far fa-circle"/>
              <SideBarLi text="Timeline" class="far fa-circle"/>
              <SideBarLi text="Ribbons" class="far fa-circle"/>
            </ul>
            </SideBarLi>
            <SideBarLi text="Forms" class="fas fa-edit">
            <ul className="nav nav-treeview">
              <li className="nav-item">
                <a href="../forms/general.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>General Elements</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../forms/advanced.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Advanced Elements</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../forms/editors.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Editors</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../forms/validation.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Validation</p>
                </a>
              </li>
            </ul>
            </SideBarLi>
            <SideBarLi text="Tables" class="fas fa-table">
            <ul className="nav nav-treeview">
              <li className="nav-item">
                <a href="../tables/simple.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>Simple Tables</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../tables/data.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>DataTables</p>
                </a>
              </li>
              <li className="nav-item">
                <a href="../tables/jsgrid.html" className="nav-link">
                  <i className="far fa-circle nav-icon"></i>
                  <p>jsGrid</p>
                </a>
              </li>
            </ul>
            </SideBarLi>
          <li className="nav-header">EXAMPLES</li>





         </ul>
      </nav>

    </div>
   
  </aside>


    )
}
export default SidebarW;