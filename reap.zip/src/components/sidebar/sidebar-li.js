import {useState} from 'react';
function SideBarLi(props){
    let child;
    let hasChildren = false;
    if(props.children){
        child =<i className="right fas fa-angle-left"></i>;  
       // e.stopPropagation();
       hasChildren = true;
    }
    const [openStatus ,setOpenStatus]= useState(false);
    let openThis = e =>{
      e.stopPropagation();
      e.preventDefault();
       // openStatus = !openStatus;
       //console.log(props.children)
      if(props.children){

        setOpenStatus(!openStatus);
        props.setOpenStatus(openStatus);
      }  

      props.AddTab(props.comp);

    }
    return (
        <li className={`nav-item ${openStatus?"menu-is-opening menu-open":""} `} onClick={openThis} >
        <a className={` no-sel nav-link ${openStatus?"active":""}  `} >
          <i className={ `${props.class} nav-icon`}></i>
          <p>{props.text}
           {child} 
          </p>
        </a>
     
        {props.children}
      </li>
    )
}
export default SideBarLi;