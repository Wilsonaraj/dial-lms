function SMItem(props){
    return(
<li >                      
                        <a className="collapsible-header waves-effect"  href="www.r.com">
                          <i className={props.icon}></i>
                          <span style={{marginLeft:"9px"}}>{props.children}</span>
                        </a>
</li>
    )
}
export default SMItem;