import DropDown from './dropDown';
function DropDownGroup(props){
    return(
<li className="collapsed"
>
  <DropDown name={props.title} />
  <div className="collapsible-body" >
    <ul className="sub-menu">
        {props.children}
    </ul>
    </div>
              </li>
        )
        }
    export default DropDownGroup;