function DropDown(props){
    return(
        <a className="collapsible-header waves-effect arrow-r"
                href="www.r.com"
                >
                    <i className="fas fa-caret-down"></i>
                 {props.name}
                  
                </a>
    )
}
export default DropDown;