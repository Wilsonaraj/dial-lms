import React from 'react';
import './sidebar.css'
import SMItem from './SMItem';
import DropDown from './dropDown';
import DropDownGroup from './DropDownGroup';
function Sidebar(){

    return(
<div className="sidebar bg-light" >
    
    <hr/>
    <div className="menu-items">

    
            <ul id="side-menu" className="collapsible collapsible-accordion"
            
            >
              
              
                  <DropDownGroup title="User Management">
                   <SMItem icon="fas fa-table" >Users</SMItem>
                   <SMItem >AG Table</SMItem>
                   <SMItem >Study Requests</SMItem>
                   </DropDownGroup>

                   <DropDownGroup title="Admin">
                    


                  <SMItem >Form List</SMItem>
                  <SMItem >Study Builder</SMItem>
                  <SMItem >Premium Support</SMItem>
                      <DropDownGroup title="User Management">

                      <SMItem >Form List</SMItem>
                      <SMItem >Study Builder</SMItem>
                      <SMItem >Premium Support</SMItem>
                      </DropDownGroup>
                    <li>
                      <a className="collapsible-header waves-effect " href="www.r.com"  >Updates</a>
                    </li>
                    </DropDownGroup>
         </ul>
        </div>
</div>


    )
}
export default Sidebar;