import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import React, { useState } from 'react';

function useTab(){

}
const TabsBar=() =>{
    const [content, setContent] = useState("one");
    const names = [
        {name:'James',compo:"one"}, 
        {name:'Paul',compo:"two"}, 
        {name:'John',compo:"three"}, 
        {name:'George',compo:"four"}
    ]
  return (
    <div>
    <nav>
    <div className="nav nav-tabs" id="nav-tab" role="tablist">
    {names.map((obj,index) => (
      <button className="nav-link active" type="button" 
      id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true"
      >{obj.name}<div  className="fa fa-window-close red clb" ></div>
      
      </button>
      
    ))}
      </div>
  </nav>
  <div className="tab-content" id="nav-tabContent">
  <div className="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">{content}</div>
  
</div>
  </div>
  );
}

export default TabsBar;