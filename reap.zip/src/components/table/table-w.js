import React, { useState } from 'react';
import JsonData from './users.json';
import ShowRow from './show-row/show-row';
import "./table.css";
import './jsgrid-theme.min.css'
import axios from 'axios';
import { useEffect } from 'react'


function TableW(){
  //  const filenames = Object.keys(JsonData[0]);
	//console.log(filenames)

const [drag, setDrag] = useState(false);

let headers_ = [
    {"name":"First Name",  "dataField":"firstName",  "width":"160px"},
    {"name":"Gender",  "dataField":"gender",  "width":"100px"},
    {"name":"Email Id",  "dataField":"emailId",  "width":"100px"},
    {"name":"Last Name",  "dataField":"lastName",  "width":"100px"},
    {"name":"Middle Name",  "dataField":"middleName",  "width":"100px"},
    {"name":"Mobile Number",  "dataField":"mobileNumber",  "width":"100px"},
    {"name":"City",  "dataField":["address","city"],  "width":"100px"},
    {"name":"Full Address",  "dataField":["address","fullAddress"],  "width":"100px"},
    {"name":"Country",  "dataField":["address","country"],  "width":"100px"},
    {"name":"PIN",  "dataField":["address","postalCode"],  "width":"100px"},
    {"name":"State",  "dataField":["address","state"],  "width":"100px"},
];
let rowL = headers_.length;
const handleStart = (e, row, col) => {

	let iniMouse = e.clientX;
	let iniSize  = document.getElementById(`${row}${col}`).offsetWidth;
	
	setDrag({
		iniMouse: iniMouse,
		iniSize:  iniSize
	})

}
 /////////////////////////////////////////
const[ api_table , setTable] = useState([]);
 useEffect(() => {
    // Code here will run just like componentDidMount
  
 let loginDetails  = JSON.parse(localStorage.getItem('loginDetails'))
 //const [token,setToken] = useState(loginDetails.access_token);
 let token = loginDetails.access_token;
 const headers= {
   'Content-Type': 'application/json',
   'authorization': 'Bearer '+token
 };
 //let spring = process.env.SPRING_BOOT_BASE_URL;
 ///console.log(spring)
  axios.get("http://localhost:8080/profiles/me",{headers})
	 .then(response=> {
	   //console.log(response)
	  // api_table = response.data;
	  return response
	   //console.log(api_table)
	 }).then(data=>{
		setTable([data.data])
		//console.log(data.data)
	 })
	}, [])
 /////////////////////////////////////////
const handleMove = (e, row, col) => {

	if(e.clientX){
		let iniMouse = drag.iniMouse;
		let iniSize  = drag.iniSize;
		let endMouse = e.clientX;
		let endSize = iniSize + (endMouse - iniMouse);
		document.getElementById(`${row}${col}`).style.width = `${endSize}px`;
	}
}
const process = (data,obj)=>{
//	console.log(obj.dataField)
	if(typeof(obj.dataField)=="object"){
		/* obj.dataField.map(
			(i)=>{
				console.log(data[i])
				//return process(data,data[i]);
			}
			 
		) */
		return data[obj.dataField[0]][obj.dataField[1]]
	}
	return (data[obj.dataField]	)
}
	return(
		<div>
             <ShowRow />
			<table className="table  jsgrid-table">
				<thead>
					<tr className='jsgrid-header-row'>
					{headers_.map(
					(info,k)=>{
						return<td		
						className='jsgrid-header-cell jsgrid-header-sortable text-center'
						key = {k} id = {`h_${k}`}
						width={info.width}>
							{info.name}		

						<div 
                            className   = 'Dragger'
                            draggable   = {true}
                            onDragStart = {(e) => handleStart(e, "h_", k)}
                            onDrag      = {(e) => handleMove(e, "h_", k)}
                        />
						</td>						
					})}
					</tr>
				</thead>
				<tbody>
			
		{api_table?.map(
        (info,row)=>{
            return(
                <tr key = {row} className='jsgrid-row'>
			{headers_.map( (col,i) =>{
        		return <td className={`jsgrid-cell ${headers_[i].render?"text-center":"text-start"}`}
			
				key = {i} id = {`${row}${i}`}
				>
					{/*(typeof(headers_[i].dataField) == "object")?"arrray":"-"}
					{headers_[i].render && (typeof(headers_[i].dataField) != "object")?
					<img className='img-responsive table-image' 
					src={info[headers_[i].dataField]} />:
					typeof(headers_[i].dataField)*/}
					{process(info,headers_[i])}
				
				<div 
                    className   = 'Dragger'
                    draggable   = {true}
                    onDragStart = {(e) => handleStart(e, row, i)}
                    onDrag      = {(e) => handleMove(e, row, i)}
                />
				</td>
     		})}
                    
                 
					
                </tr>
            )
        }
    )}
				
				</tbody>
			</table>
			
		</div>
	)
}

export default TableW;
