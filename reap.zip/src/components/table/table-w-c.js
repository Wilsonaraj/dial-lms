import React, { useState } from 'react';
import JsonData from './users.json';
import ShowRow from './show-row/show-row';
import "./table.css";
import './jsgrid-theme.min.css'
import axios from 'axios';
import { useEffect } from 'react'

function TableWClient(){
  //  const filenames = Object.keys(JsonData[0]);
	//console.log(filenames)

const [drag, setDrag] = useState(false);

let headers_ = JsonData.headers;
let rowL = headers_.length;
const handleStart = (e, row, col) => {

	let iniMouse = e.clientX;
	let iniSize  = document.getElementById(`${row}${col}`).offsetWidth;
	
	setDrag({
		iniMouse: iniMouse,
		iniSize:  iniSize
	})

}
 
const handleMove = (e, row, col) => {

	if(e.clientX){
		let iniMouse = drag.iniMouse;
		let iniSize  = drag.iniSize;
		let endMouse = e.clientX;
		let endSize = iniSize + (endMouse - iniMouse);
		document.getElementById(`${row}${col}`).style.width = `${endSize}px`;
	}
}
	return(
		<div>
             <ShowRow />
			<table className="table  jsgrid-table">
				<thead>
					<tr className='jsgrid-header-row'>
					{headers_.map(
					(info,k)=>{
						return<td		
						className='jsgrid-header-cell jsgrid-header-sortable text-center'
						key = {k} id = {`h_${k}`}
						width={info.width}>
							{info.name}		

						<div 
                            className   = 'Dragger'
                            draggable   = {true}
                            onDragStart = {(e) => handleStart(e, "h_", k)}
                            onDrag      = {(e) => handleMove(e, "h_", k)}
                        />
						</td>						
					})}
					</tr>
				</thead>
				<tbody>
			
		{JsonData.data.map(
        (info,row)=>{
            return(
                <tr key = {row} className='jsgrid-row'>
			{headers_.map( (col,i) =>{
        		return <td className={`jsgrid-cell ${headers_[i].render?"text-center":"text-start"}`}
			
				key = {i} id = {`${row}${i}`}
				>
					{headers_[i].render?<img className='img-responsive table-image' src={info[headers_[i].dataField]} />:info[headers_[i].dataField]}
				
				<div 
                    className   = 'Dragger'
                    draggable   = {true}
                    onDragStart = {(e) => handleStart(e, row, i)}
                    onDrag      = {(e) => handleMove(e, row, i)}
                />
				</td>
     		})}
                    
                 
					
                </tr>
            )
        }
    )}
				
				</tbody>
			</table>
			
		</div>
	)
}

export default TableWClient;
