import React, { useState } from 'react';
import "./table.css";
import ShowRow from './show-row/show-row';
const Table = () => {

    const [drag, setDrag] = useState(false);

    const data = [
        ["Pfizer PfizerPfizerPfizerPfizerPfizerPfizerPfizerPfizerPfizerPfizerPfizerPfizerPfizerPfizer",
        "pfi",
        "https://www.pfizer.com/",
        "Whitefield, Bengaluru",
        "Srilanka",
        "Karnataka",
        "Bengaluru",
        'http://edcadp.000webhostapp.com/php/upload/635ad02cc7121.jpeg',
        "+91-7777777777",
        "+91-9999999999",
        "Tier 3"],
        [ "Calpol",
        "pfi",
        "https://www.pfizer.com/",
        "North Usmaan Road, East Hyderabad",
        "India",
        "Telangana",
        "Hyderabad",
        "http://edcadp.000webhostapp.com/php/upload/635acaaf07423.png",
        "+91-8888888888",
        "+91-9999999999",
        "Tier 3"]
    ];
   let headers = [
    

      ]
      let nameArr = headers.map(row=>{return row.name})
      
     let bata = [nameArr,...data]
     console.log(bata[0])
    const handleStart = (e, row, col) => {

        let iniMouse = e.clientX;
        let iniSize  = document.getElementById(`${row}${col}`).offsetWidth;
        
        setDrag({
            iniMouse: iniMouse,
            iniSize:  iniSize
        })

    }

    const handleMove = (e, row, col) => {

        if(e.clientX){

            let iniMouse = drag.iniMouse;
            let iniSize  = drag.iniSize;
            let endMouse = e.clientX;

            let endSize = iniSize + (endMouse - iniMouse);

            document.getElementById(`${row}${col}`).style.width = `${endSize}px`;

        }

    }
    const selectRow = (val)=>{
      //  e.preventDefault();
   // e.stopPropagation();
       // if(e.currentTarget != e.target ) return;
        console.log(val);
    }
    return(
        <div>
        <ShowRow />
        
        <table className="table table-bordered">

            <tbody>
                {bata.map((row, i) => 
                    <tr id = {`${i}`} key = {i} onClick={()=>selectRow(`${i}`)}>
                        {row.map((col, j) => 
                            <td  key = {j} id = {`${i}${j}`}>
                                {bata[i][j]}
                                <div 
                                    className   = 'Dragger'
                                    draggable   = {true}
                                    onDragStart = {(e) => handleStart(e, i, j)}
                                    onDrag      = {(e) => handleMove(e, i, j)}
                                />
                            </td>
                        )}
                    </tr>
                )}
            </tbody>
        </table>
        </div>
    );

}

export default Table;