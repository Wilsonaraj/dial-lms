import "./show-row.css"
    function ShowRow(){
      let refreshTable = () =>{}
      let EditRow = () =>{}
      let deleteRows = () =>{}

    return(
      <div>
    <ul className="nav showRow">
        <li className="nav-item">
          <a className="nav-link" ><i className="fa fa-filter ico"></i></a>
        </li>
        <li className="nav-item">
          <a className="nav-link" onClick={refreshTable}><i className="fa fa-refresh ico"></i></a>
        </li>
        <li className="nav-item">
          <a className="nav-link" onClick={deleteRows} ><i className="fa fa-remove ico"></i></a>
        </li>

        <li className="nav-item">
            <a className="nav-link"  ><i className="fa fa-download ico"></i></a>
        </li>
        <li className="nav-item">
            <a className="nav-link"  onClick={EditRow}><i className="fa fa-edit ico"></i></a>
        </li>
        
        
        <li className="nav-item d-flex input-group-sm"  style={{position:"absolute",right:"30px"}}>
            <span className="fll">Showing </span>
        <select className="form-select fll"  aria-label="Default select example">
      
      <option value="0">1-100</option>
      <option value="1">101-200</option>
      <option value="2">201-300</option>
      <option value="3">301-400</option>
    </select>
          </li>
      </ul>
      </div>
        )
  
    }
    export default ShowRow;