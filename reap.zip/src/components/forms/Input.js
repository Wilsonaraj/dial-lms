import React from "react";
import './user-form.css';
/* import "./Input.css"; */

function InputField(props) {
  const {
    key,
    label,
    type,
    name,
    handleChange,
    placeholder,
    errorMessage,
    isValid,
    value,
    data=[]
  } = props;

  return (
    <div className="form-group">
      <label className="form-label">{label}</label>
      {(type=="text" || type=="email" || type=="password")?
      <input 
      key={key}
      type={type} 
      name={name} 
      value={value} 
      onChange={handleChange} 
      placeholder={placeholder}
      className="form-control form-control-sm" />:""}
        {(type=="textarea")?
      <textarea 
      key={key}
      name={name} 
      value={value} 
      onChange={handleChange} 
      placeholder={placeholder}
      className="form-control form-control-sm" />:""}

{(type=="select")?
      <select 
      key={key}
      name={name} 
      value={value} 
      onChange={handleChange} 
      placeholder={placeholder}
     
      className="form-control form-control-sm form-select" >
         {data.map((cont) => (
        <option value={cont}>{cont}</option>
      ))}
       
         </select>
        :""}


      {errorMessage && !isValid && (
        <span className="warn">{errorMessage}</span>
      )}
    </div>
  );
}

export default React.memo(InputField);
