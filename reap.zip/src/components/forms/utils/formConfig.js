import React from "react";
import Input from "../Input";

import {
  requiredRule,
  minLengthRule,
  maxLengthRule,
  passwordMatchRule
} from "./inputValidationRules";

/**
 * creates and returns object representation of form field
 *
 * @param {string} label - label to show with the form input
 * @param {string} name - input name
 * @param {string} type - input type
 * @param {string} placeholder - input type
 * @param {array} data - input type
 * @param {string} key - input type
 * @param {string} defaultValue - default value for the input
 */
function createFormFieldConfig(label, name, type, placeholder,key,data,defaultValue = "") {
  return {
    renderInput: (handleChange, value, isValid,error) => {
      return (
        <Input
          key={key}
          name={name}
          type={type}
          label={label}
          isValid={isValid}
          placeholder={placeholder}
          value={value}
          handleChange={handleChange}
          errorMessage={error}
          data = {data}
        />
      );
    },
    label,
    value: defaultValue,
    valid: false,
    errorMessage: "",
    touched: false
  };
}

// object representation of signup form
export const signupForm = {
  fname: {
    ...createFormFieldConfig("Full Name", "fname", "text","Enter Full Name", "fname"),
    validationRules: [
      requiredRule("fname"),
      minLengthRule("fname", 3),
      maxLengthRule("fname", 25)
    ]
  },
  sname: {
    ...createFormFieldConfig("Short Name", "sname", "text","Enter Short Name", "sname"),
    validationRules: [
      requiredRule("sname"),
      minLengthRule("sname", 3),
      maxLengthRule("sname", 8)
    ]
  },
  web: {
    ...createFormFieldConfig("Client Website", "web", "text","Client Website", "web"),
    validationRules: [
      requiredRule("web"),
      minLengthRule("web", 8)
    ]
  },
  address: {
    ...createFormFieldConfig("Client address", "address", "textarea","Enter Address", "address"),
    validationRules: [
      requiredRule("address"),
      minLengthRule("address", 10),
      maxLengthRule("address", 65)
    ]
  },
  country: {
    ...createFormFieldConfig("Client Country", "country", "select","Enter Country", "country",["a","b","c"]),
    validationRules: [
      
     
    ]
  }
};
