import React from "react";
import useForm from "./useForm";
import { signupForm } from "./utils/formConfig";

/* import "./styles.css"; */
/* import "./SignupForm.css"; */

export default function SignupForm() {
  const { renderFormInputs, isFormValid } = useForm(signupForm);

    const formData = {
    fullName: "", 
    shortname: "", 
    website: "", 
    address: "",
    country: "",
  
  }
const onSubmitHandler = (e) =>{
  e.preventDefault();
  //const arr = Object.values(signupForm);
  formData.fullName = e.target[0].value;
  formData.shortname = e.target[1].value;
  formData.website = e.target[2].value;
  formData.address = e.target[3].value;
  formData.country = e.target[4].value;

  console.log(formData)
}
  return (
<div className="row p-3" id="client-data">
    
 
  <div className="col-lg-6">
    <form className="signupForm" onSubmit={onSubmitHandler}>

      {renderFormInputs()}
      <button type="submit" disabled={!isFormValid()}>
        Submit
      </button>
    </form>
  </div>
</div>
  );
}
