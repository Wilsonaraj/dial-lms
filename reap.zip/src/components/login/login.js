import './login.css';
import axios from 'axios';
import { useState, useEffect } from 'react';
import qs from 'qs';
import { Formik, Field, Form } from "formik";
function Login(props){
/* const setLoginDetails = (loginDetails)=>{
  
  localStorage.setItem('loginDetails', JSON.stringify(loginDetails));
  console.log('set')
} */

const [loginStatus,setLoginStatus] = useState(false);
const [tryStatus,setTryStatus] = useState(false);

const callAPI = (name) =>{
  
props.callAPI(name)

}
/* const setUserDetails = (userDetails)=>{
  
  localStorage.setItem('userDetails', JSON.stringify(userDetails));
} */
const [user, setUser] = useState( localStorage.getItem('userDetails'),'[]'); 
const [userData, setLoginDetails] = useState( localStorage.getItem('loginDetails'),'[]'); 
let atOken = JSON.parse(userData)?.access_token;
if(atOken){
  callAPI("boss")
}
return(
<div id="login" className="hold-transition login-page">
<div className="login-box">
    <div className="login-logo">
      <div className='logo-text'><b>EDC</b>Tech</div>
    </div>
   
    <div className="card">
      <div className="card-body login-card-body">
        <p className="login-box-msg"> Sign in to start your session</p>
        <Formik
        initialValues={{ username: "", password: "" }}
        onSubmit={async (values) => {
          
          await new Promise((resolve) => setTimeout(resolve, 500));
          console.log(values);
          values.grant_type= 'password';
          ///////////////////////////////////////////
          var data = qs.stringify(values);
          var config = {
            method: 'post',
            url: 'http://localhost:8080/oauth/token',
            headers: { 
              'Accept': 'application/json, text/plain, */*', 
              'Accept-Language': 'en-US,en;q=0.9', 
              'Authorization': 'Basic Y2xpZW50OmNsaWVudFNlY3JldA==', 
              'Connection': 'keep-alive', 
              'Content-Type': 'application/x-www-form-urlencoded', 
              'Origin': 'http://localhost:8080', 
              'Referer': 'http://localhost:8080/swagger-ui/index.html', 
              'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 
              'X-Requested-With': 'XMLHttpRequest'
            },
            data : data
          };
          
          axios(config)
          .then(function (response) {
            let resData = JSON.stringify(response.data);
            let userData = JSON.stringify(values);
            
        if(response.data.access_token != undefined){
            //  setLoginDetails(resData);
             // setUserDetails(values);
           //  useEffect(() => {
            setLoginStatus(true)
              setLoginDetails (localStorage.setItem('loginDetails', resData));
              setUser (localStorage.setItem('userDetails', userData));
              callAPI("boss")  
              console.log(resData);
          //  });
             
             setUser(values.username)
          
            // localStorage.setItem('userDetails', JSON.stringify(values));
           }else{
            setLoginStatus(false)
           }
           
          })
          .catch(function (error) {
            console.log(error);
            setTryStatus(true)
           
          });
          ///////////////////////////////////////////
        }}
      >
        <Form >
          <div className="input-group mb-3">
            <Field name="username" type="text" className="form-control form-control-sm" placeholder="Email"/>
            <div className="input-group-append">
              <div className="input-group-text">
                <span className="fas fa-envelope"></span>
              </div>
            </div>
          </div>
          <div className="input-group mb-3">
            <Field  name="password" type="password" className="form-control form-control-sm" placeholder="Password"/>
            <div className="input-group-append">
              <div className="input-group-text">
                <span className="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-8">
              <div className="icheck-primary">
                <input type="checkbox" id="remember"/>
                <span>&nbsp;</span>
                <label htmlFor="remember">
                  Remember Me
                </label>
              </div>
            </div>
          
            <div className="col-4">
              <button type="submit" className="btn brnd btn-sm">Sign In</button>
            </div>
         
          </div>
        </Form>
        </Formik>
        <p className={` ${(!loginStatus && tryStatus)?"error":"no-error"} `}>Incorrect Credentials..</p>
       {/*  <p className="mb-1">
          <a >I forgot my password</a>x
        </p>
        <p className="mb-0">
          <a className="text-center">Register a new membership</a>
        </p> */}
      </div>
    
    </div>
  </div>
  </div>
)
}
export default Login;