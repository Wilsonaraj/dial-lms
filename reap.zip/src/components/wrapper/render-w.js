import Login from '../login/login';
import LoggedIn from "./logged-in";
import React, {useState} from "react";
function RenderW(props) {
    const [loginStatus,setLoginStatus] = useState(true);

    const logout =() =>{
        setLoginStatus(false)
    }
    const callAPI = (name) =>{
        console.log("In wrapper", name);
        setLoginStatus(true);
      }
    //const isLoggedIn = props.isLoggedIn;
    if (!loginStatus) {
      return <Login callAPI={callAPI}/>;
    }else{
        return <LoggedIn logout={logout}/>;
    }
   
  }
  export default RenderW;