
import Header from "../header/header";
import TabsN from "../tabs/tabsW";
import Footer from "../footer/footer";
import Sidebar from '../sidebar/side-bar';
import 'bootstrap/dist/css/bootstrap.min.css';
import SidebarW from "../sidebar/side-barW"; 
import LoggedIn from "./logged-in";
import Login from '../login/login'
/*import HeaderNew from "../header/header-new"

 import SidebarW from "../sidebar/side-barW"; 


import TabsBar from "../tabs-bar";

import GmailTreeView from '../../tree.js';
import TabsW from "../tabs/tabs";

import User from "../UserProfile";
import SBar from "../sidebar/sBar"; */
import { useRef } from "react";
import './wrapper.css';
import RenderW from "./render-w";
function WrapperW(props){

  let loginStatus =  true;
  
  /* export function renderCont(){
    if(loginStatus){
      return <LoggedIn />
    }
  } */
 
    return(
        <div>
       
<div className="container-fluid">


  <div className="row flex-xl-nowrap" >
  <RenderW />
  </div>
</div>

</div>

  
    )
}
export default WrapperW;