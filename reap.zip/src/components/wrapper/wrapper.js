import React, {useState} from "react";
import Header from "../header/header";
import TabsN from "../tabs/tabsW";
import Footer from "../footer/footer";
import Sidebar from '../sidebar/side-bar';
import 'bootstrap/dist/css/bootstrap.min.css';
import SidebarW from "../sidebar/side-barW"; 
/*import HeaderNew from "../header/header-new"

 import SidebarW from "../sidebar/side-barW"; 


import TabsBar from "../tabs-bar";

import GmailTreeView from '../../tree.js';
import TabsW from "../tabs/tabs";

import User from "../UserProfile";
import SBar from "../sidebar/sBar"; */
import './wrapper.css';
function Wrapper(props){
  const [panel , showPanelState] = useState(false);
  
  const showPanel = ()=>{
  
  showPanelState(!panel);
  console.log("show panel")
}
    return(
        <div>
        <Header showPanel={showPanel}/>
<div className="container-fluid">
  
  <div className="row flex-xl-nowrap">
  <div className={`sideHolder ${panel?"col-lg-2 showS":"hideS"}`}
 
  >
<Sidebar />


  </div>
  <div className={`contentArea ${panel?"col-lg-10":"col-lg-12"} `} >
    
    <div className="content-fluid">
      
    <TabsN />

    <div className="rout" >
    {props.children}
    
  </div>
  <Footer/>
</div>
  
  
  </div>
  </div>
</div>

</div>

  
    )
}
export default Wrapper;