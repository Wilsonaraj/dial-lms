import Header from "../header/header";
import TabsN from "../tabs/tabsW";
import Footer from "../footer/footer";
import SidebarW from '../sidebar/side-barW';
import React, {useState, useRef} from "react";
function LoggedIn(props){
  const [panel , showPanelState] = useState(true);
  let tabChild = useRef(null)
  const childRef = useRef(null);
 
  const showPanel = ()=>{
  
  showPanelState(!panel);
  console.log("show panel")
}
const AddTab = (comp) =>{
  
  childRef.current.addTab(comp);
}

    return(
<>
<div className={`sideHolder ${panel?"col-lg-2 showS":"hideS"}`}

>

<SidebarW AddTab={AddTab}/>

</div>
<div className={`contentArea ${panel?"col-lg-10":"col-lg-12"} `} >
  
  <div className="content-fluid">
  <Header showPanel={showPanel} logout={props.logout}/>
  <TabsN ref={childRef }  />

  <div className="rout" >
  {props.children}
  
</div>
<Footer/>
</div>


</div>
</>
    )
}
export default LoggedIn;