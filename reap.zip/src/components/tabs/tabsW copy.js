import TabWItem from "./tabWItem";
import './tabs-bar.css';
import React,{useState} from "react";
import Table from "../table/table";
function TabsN(){
  const [key, setKey] = useState('home');
  const [bool, setSelected] = useState([true,false,false,false]);
  let disabled = false;
  const closeTab = e =>{
    e.preventDefault();
    e.stopPropagation();
    
  }
  /////////////////////////////////////////
  let tabList = [
    {name:"Home", comp:<Table/>},
    {name:"Home", comp:<Spin/>},
  ]
  /////////////////////////////////////////
  const changeTab = (num)=>{
    const allWithclassName = Array.from(
      document.querySelectorAll('.show')
    );
    console.log(allWithclassName[0]);
    //allWithclassName[0].classNameList.remove("show").add("fade")
    let falseArray = [false,false,false,false]
    falseArray[num] = true;
    setSelected(falseArray);
 //let selElt =  e.target.getAttribute('targetTab')
  setKey("profile")
 // selElt.classNameList.add('click-state');
  console.log(num);
  }
    return(
        <div className="card card-primary card-tabs">
              <div className="card-header p-0 pt-1 MainTab">  
                <ul className="nav nav-tabs container MainTab" id="custom-tabs-one-tab" role="tablist">
                <TabWItem active={bool[0]} click={changeTab.bind(null,0)}>Home</TabWItem>
                <TabWItem  active={bool[1]} click={changeTab.bind(null,1)}>Pro</TabWItem>
                <TabWItem  active={bool[2]} click={changeTab.bind(null,2)}>Messages</TabWItem>
                <TabWItem  active={bool[3]} click={changeTab.bind(null,3)}>settings</TabWItem>
                  
                </ul>
              </div>
              <div className="card-body">
                <div className="tab-content" id="custom-tabs-one-tabContent">
                  <div 
                 
                  className={`tab-pane fade  ${bool[0] ? "show active" : "fade"} ${ disabled ? "disabled" : ""   }`}
                  id="custom-tabs-one-home" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
                    
                     <Table />
                  </div>
                  <div  className={`tab-pane fade  ${bool[1] ? "show active" : "fade"} ${ disabled ? "disabled" : ""   }`} id="custom-tabs-one-profile" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                     Mauris tincidunt mi at erat gravida, eget tristique urna bibendum. Mauris pharetra purus ut ligula tempor, et vulputate metus facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas sollicitudin, nisi a luctus interdum, nisl ligula placerat mi, quis posuere purus ligula eu lectus. Donec nunc tellus, elementum sit amet ultricies at, posuere nec nunc. Nunc euismod pellentesque diam.
                  </div>
                  <div  className={`tab-pane fade  ${bool[2] ? "show active" : "fade"} ${ disabled ? "disabled" : ""   }`} id="custom-tabs-one-messages" role="tabpanel" aria-labelledby="custom-tabs-one-messages-tab">
                     Morbi turpis dolor, vulputate vitae felis non, tincidunt congue mauris. Phasellus volutpat augue id mi placerat mollis. Vivamus faucibus eu massa eget condimentum. Fusce nec hendrerit sem, ac tristique nulla. Integer vestibulum orci odio. Cras nec augue ipsum. Suspendisse ut velit condimentum, mattis urna a, malesuada nunc. Curabitur eleifend facilisis velit finibus tristique. Nam vulputate, eros non luctus efficitur, ipsum odio volutpat massa, sit amet sollicitudin est libero sed ipsum. Nulla lacinia, ex vitae gravida fermentum, lectus ipsum gravida arcu, id fermentum metus arcu vel metus. Curabitur eget sem eu risus tincidunt eleifend ac ornare magna.
                  </div>
                  <div  className={`tab-pane fade  ${bool[3] ? "show active" : "fade"} ${ disabled ? "disabled" : ""   }`} id="custom-tabs-one-settings" role="tabpanel" aria-labelledby="custom-tabs-one-settings-tab">
                     Pellentesque vestibulum commodo nibh nec blandit. Maecenas neque magna, iaculis tempus turpis ac, ornare sodales tellus. Mauris eget blandit dolor. Quisque tincidunt venenatis vulputate. Morbi euismod molestie tristique. Vestibulum consectetur dolor a vestibulum pharetra. Donec interdum placerat urna nec pharetra. Etiam eget dapibus orci, eget aliquet urna. Nunc at consequat diam. Nunc et felis ut nisl commodo dignissim. In hac habitasse platea dictumst. Praesent imperdiet accumsan ex sit amet facilisis.
                  </div>
                </div>
              </div>
            </div>
    )
}
export default TabsN;