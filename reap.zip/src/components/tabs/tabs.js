import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import './tabs-bar.css';
import Table from '../table/table';
import React, { useState } from 'react';
import Spin from '../spin/spin';

function TabsW() {
    const [key, setKey] = useState('home');
   const clickHandler = (e) =>{
        e.preventDefault();
    }
    var ObjectArr = [{title:"home",component:Table},{title:"profile",component:Spin}]
    const rows = [];
    for (var i=0; i < ObjectArr.length; i++) {
      rows.push(
      <Tab eventKey={ObjectArr[i].title} title={<span>{ObjectArr[i].title} 
      <i className=" fa fa-window-close red clb" 
      onClick={clickHandler}/> </span>}>
      {ObjectArr[i].component()}
      </Tab>
      )
      
 } 
   
  return (
    <Tabs
      defaultActiveKey="profile"
      id="controlled-tab-example"
      activeKey={key}
      onSelect={(k) => setKey(k)}
      className="mb-3"
    >
      
      {rows}
   
    </Tabs>
  );
}

export default TabsW;