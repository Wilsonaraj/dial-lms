import TabWItem from "./tabWItem";
import './tabs-bar.css';
import React,{forwardRef, useImperativeHandle, useState} from "react";
import Table from "../table/table";
import Spin from '../spin/spin'
import NestedGrid from '../../grid'
import TableW from "../table/table-w";
import UserForm from "../user-form/user-form";
import { uuid } from "uuidv4";
import SignupForm from "../forms/form";
import axios from 'axios';
import FormicW from "../formic/formicW";

const TabsN = forwardRef((props,ref)=>{
  const [key, setKey] = useState('home');
  const [bool, setSelected] = useState([true,false,false,false]);
  /////////////////////////////////////////
  useImperativeHandle(ref, () => ({
    addTab(val) {
      console.log('child function 1 called'+val);
      addTab(val)
    },
    childFunction2() {
      console.log('child function 2 called');
    },
  }));
  /////////////////////////////////////////
  let tabArr = [
    {name:"Home", comp:<Table/>},
    {name:"Spin", comp:<Spin/>}
  ]
  ///////////////////////////////////////// */


  const [tabList, setTabList] = useState( [
    
  ])
  let disabled = false;
  //////////////////////////
  const addTab = (comp) =>{
    if(tabList.some((obj) => obj.id === comp.id)){
      makeActive(comp.id)
      return;
    }
    setTabList( [...tabList,comp])

    makeActive(tabList.length)
  }
  //////////////////////////
  let closeTab = num =>{

  //tabList.splice(num,1)
    setTabList( tabList.filter(a =>
      a.name !== num
    ))
    
    makeActive(0)
  }
  
  const makeActive = (num) =>{
    let falseArray = [ ...Array(tabList.length) ].map((i)=>false)
    falseArray[num] = true;
    setSelected(falseArray);
  }
  const changeTab = (num)=>{
    const allWithclassName = Array.from(
      document.querySelectorAll('.show')
    );
  
    //allWithclassName[0].classNameList.remove("show").add("fade")
    makeActive(num)

   /*  setTabList( tabList.map((item)=>{
      console.log(item.id==num);
      if(item.id === num){
        return {...item,active:true}
      }else{
        return {...item,active:false}
      }
      
    }))
    console.log(tabList) */
   // setTabList(tabList)
 //let selElt =  e.target.getAttribute('targetTab')
  setKey("profile")
 // selElt.classNameList.add('click-state');
  console.log(num);
  }
    return(
        <div className="card card-primary card-tabs" id="TabsW"> 
              <div className="card-header p-0 pt-1 MainTab">  
                <ul className="nav nav-tabs container MainTab" id="custom-tabs-one-tab" role="tablist">
               { tabList.map((item,i) =>
<TabWItem closeTab={closeTab} num={item.name}  id={item.id}  key={item.id}  active={bool[i]} click={changeTab.bind(null,i)}>{item.name}</TabWItem>
                )}
                
             {/*    <TabWItem  active={bool[1]} click={changeTab.bind(null,1)}>Pro</TabWItem>
                <TabWItem  active={bool[2]} click={changeTab.bind(null,2)}>Messages</TabWItem>
                <TabWItem  active={bool[3]} click={changeTab.bind(null,3)}>settings</TabWItem> */}
                  
                </ul>
              </div>
              <div className="card-body">
                <div className="tab-content" id="custom-tabs-one-tabContent">
                { tabList.map((item,i) =>
                  <div 
                 
                  className={`tab-pane fade  ${bool[i] ? "show active" : "fade"} ${ disabled ? "disabled" : ""   }`}
                  id={item.name}  key={item.name} role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
                    
                     {item.comp}
                  </div>
                )}
                 {/*  <div  className={`tab-pane fade  ${bool[1] ? "show active" : "fade"} ${ disabled ? "disabled" : ""   }`} id="custom-tabs-one-profile" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                     Mauris tincidunt mi at erat gravida, eget tristique urna bibendum. Mauris pharetra purus ut ligula tempor, et vulputate metus facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas sollicitudin, nisi a luctus interdum, nisl ligula placerat mi, quis posuere purus ligula eu lectus. Donec nunc tellus, elementum sit amet ultricies at, posuere nec nunc. Nunc euismod pellentesque diam.
                  </div>
                  <div  className={`tab-pane fade  ${bool[2] ? "show active" : "fade"} ${ disabled ? "disabled" : ""   }`} id="custom-tabs-one-messages" role="tabpanel" aria-labelledby="custom-tabs-one-messages-tab">
                     Morbi turpis dolor, vulputate vitae felis non, tincidunt congue mauris. Phasellus volutpat augue id mi placerat mollis. Vivamus faucibus eu massa eget condimentum. Fusce nec hendrerit sem, ac tristique nulla. Integer vestibulum orci odio. Cras nec augue ipsum. Suspendisse ut velit condimentum, mattis urna a, malesuada nunc. Curabitur eleifend facilisis velit finibus tristique. Nam vulputate, eros non luctus efficitur, ipsum odio volutpat massa, sit amet sollicitudin est libero sed ipsum. Nulla lacinia, ex vitae gravida fermentum, lectus ipsum gravida arcu, id fermentum metus arcu vel metus. Curabitur eget sem eu risus tincidunt eleifend ac ornare magna.
                  </div>
                  <div  className={`tab-pane fade  ${bool[3] ? "show active" : "fade"} ${ disabled ? "disabled" : ""   }`} id="custom-tabs-one-settings" role="tabpanel" aria-labelledby="custom-tabs-one-settings-tab">
                     Pellentesque vestibulum commodo nibh nec blandit. Maecenas neque magna, iaculis tempus turpis ac, ornare sodales tellus. Mauris eget blandit dolor. Quisque tincidunt venenatis vulputate. Morbi euismod molestie tristique. Vestibulum consectetur dolor a vestibulum pharetra. Donec interdum placerat urna nec pharetra. Etiam eget dapibus orci, eget aliquet urna. Nunc at consequat diam. Nunc et felis ut nisl commodo dignissim. In hac habitasse platea dictumst. Praesent imperdiet accumsan ex sit amet facilisis.
                  </div> */}
                </div>
              </div>
            </div>
    )
})
export default TabsN;