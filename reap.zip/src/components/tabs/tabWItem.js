function TabWItem(props){
    let closeTab = (e,num) =>{
        e.preventDefault();
        e.stopPropagation();
        props.closeTab(num)
    }
    return(
        <li className="nav-item" key={props.id} id={props.id}>
            <a className={`nav-link ${props.active ? "active" : ""} flexbox` }
                    onClick={props.click}
            >
                <div className="blue no-sel">{props.children}</div>
                    <div className="green" onClick={(e)=>closeTab(e,`${props.num}`)}> 
                    <i className=" fa fa-window-close green clb " />
                </div>
                    
            </a>
                   
        </li>
    )
}
export default TabWItem;