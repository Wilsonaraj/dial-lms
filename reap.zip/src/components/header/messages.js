import Dropdown from 'react-bootstrap/Dropdown';
import React from 'react';

const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
  <a
    href=""
    className="nav-link"
    ref={ref}
    onClick={e => {
      e.preventDefault();
      onClick(e);
    }}
  >
    {/* Render custom icon here */}
   <i className='fa fa-comments'></i>
   <span className="badge badge-danger navbar-badge">3</span>
    {children}
  </a>
));
function Messages(){
    return(
      <li className="nav-item">
      <Dropdown>
      <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components" variant="primary" >
      
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
    </li>
    )
}
export default Messages;