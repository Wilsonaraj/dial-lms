import React, { useState } from 'react';
import './nav.css';
import Search from './search';
import Messages from './messages';
import Notifications from './notifications';
import UserInfo from './user-info';
import '@fortawesome/fontawesome-free/css/all.css';
import 'admin-lte-css-only/css/adminlte.min.css';
function Header(props){
 // const [panel , showPanelState] = useState(true);
const showPanel = (e)=>{
  e.preventDefault();
//  showPanelState(false);
  props.showPanel();
  console.log("show panel")
}
    return(
       

<nav className="main-header navbar navbar-expand-lg navbar-dark flex-column flex-md-row bd-navbar bg-brand ">
  
  <div className="container-fluid">
      <a className="navbar-brand"  onClick={showPanel}>
        <i className="fa fa-bars"></i>
      </a>
     {/*  <a className="navbar-brand" >EDC Technologies</a> */}
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar"
     >
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="mynavbar">
        <ul className="navbar-nav me-auto">
         
         
        </ul>
        
        <div className="d-flex">
          <ul className="navbar-nav ml-auto">
            <Search/>
            <Messages/>
            <Notifications/>     
            {/* <UserInfo logout={props.logout}/> */}
            
          </ul>
        </div>
      </div>
    </div>
  </nav>


    )
}
export default Header;