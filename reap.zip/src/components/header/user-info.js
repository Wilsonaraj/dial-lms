import 'admin-lte-css-only/css/adminlte.min.css';
import React,{ useState } from 'react';
import Dropdown from 'react-bootstrap/Dropdown';

function UserInfo(props){
  const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
    <a
      href=""
      className="nav-link"
      ref={ref}
      onClick={e => {
        e.preventDefault();
        onClick(e);
      }}
    >
      {/* Render custom icon here */}
     <i className='fa fa-user'></i>
     
      {children}
    </a>
  ));
 let userDetails  = JSON.parse(localStorage.getItem('userDetails'))
  const [username,setUser] = useState(userDetails.username);
  //localStorage.getItem()
  const logout =() =>{
    localStorage.removeItem("loginDetails")
    localStorage.removeItem("userDetails")
    props.logout()
  }
    
    return(
      <li className="nav-item">
      <Dropdown>
      <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components" variant="primary" >
      
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item >Hi {username}!</Dropdown.Item>
        <Dropdown.Item >My Profile</Dropdown.Item>
        <Dropdown.Item onClick={logout}>Logout</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
    </li>
    )
}
export default UserInfo;