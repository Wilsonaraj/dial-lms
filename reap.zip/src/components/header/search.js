
import './search.css';
import React,{useState} from 'react'

function Search(){
const [isOpen,showTab]=useState(true);

const handleClick = () =>{
  showTab(false);
  console.log("yes")
}
const closeThis=(e)=>{
  e.preventDefault()
  showTab(true)
}
    return(
    <li className="nav-item" id="search">
    <a className="nav-link" onClick={handleClick}>
      <i className="fa fa-search"></i>
    </a>
    <form className={"searchBar "+(isOpen?"hide":null)}>
        <div className="input-group mt-1">
            <button type="submit" className="input-group-text btn-light s-icon"><i className="fa fa-search me-2"></i> </button>
            <input type="text" className="form-control form-control-sm s-field" placeholder="Search Here"></input>
            <button className="input-group-text btn-light cl-icon" onClick={closeThis}><i className="fa fa-close me-2"></i> </button>
        </div> 
    </form>
  </li>
    )
}
export default Search;