import React from 'react';
import './footer.css';
function Footer(){

    return(
        <footer className="main-footer bg-brand text-white container-fluid" >
    <span>Copyright © 2022-2027 <a className="text-white" href="http://www.edc.com">www.edc.com</a>.</span>
    All rights reserved.
    <div className="float-right d-none d-sm-inline-block text-white">
      <b className="text-white">Version</b> 1.0.0
    </div>
  </footer>
    )
}
export default Footer;